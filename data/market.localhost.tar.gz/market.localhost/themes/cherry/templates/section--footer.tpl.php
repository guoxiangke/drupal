<footer<?php print $attributes; ?> align="center">
  <?php print $content; ?>
</footer>
