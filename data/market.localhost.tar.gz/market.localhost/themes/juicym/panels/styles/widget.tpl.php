<ul data-role="listview" data-inset="true" data-theme="c" data-dividertheme="b">
  <li data-role="list-divider"><?php print $title ?></li>
  <li><?php print render($content); ?></li>
</ul>

