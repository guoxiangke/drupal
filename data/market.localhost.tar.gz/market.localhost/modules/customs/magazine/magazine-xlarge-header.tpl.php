<div data-role="header" data-id="footer" data-theme="a" data-position="fixed">
	<h1><?php print $title; ?></h1>
	<div class="ui-btn-left" data-role="controlgroup" data-type="horizontal">
   		<a href="#section-0" data-role="button" data-icon="home" data-iconpos="notext"></a> 			
		<a href="#left-panel" class="menu" data-role="button" data-icon="bars" data-iconpos="notext" 
			data-shadow="false" data-iconshadow="false" class="ui-icon-nodisc"></a>
	</div>
	<div class="ui-btn-right" data-role="controlgroup" data-type="horizontal">
		<a href="#right-panel" data-role="button" data-icon="grid" data-iconpos="notext" 
			data-shadow="false" data-iconshadow="false" class="ui-icon-nodisc"></a>
	</div>
</div>
<div data-role="panel" id="left-panel" data-theme="d" class="left-panel">
  <ul data-role="listview" data-iscroll="true">
	<li data-role="list-divider" class="title">内容</li>
  	<?php foreach ($columns as $tid => $item): ?>
	    <li class="column column-<?php print $tid;?>">
	  	<?php if (count($item['nodes']) > 1):?>
	  	<a data-url="#section-<?php print $tid; ?>" 
	  		data-rel="<?php if (isset($cid) && $tid == $cid) print 'close'; ?>"><?php print $item['name']; ?></a>
	  	<?php else: ?>
	  	<?php print $item['name']; ?>
	  	<?php endif?>
	    </li>
  		<?php foreach ($item['nodes'] as $node): ?>
	    <li data-icon="false">
	    	<a href="<?php print $root['url'] . $node->url;?>" data-prefetch 
	    		data-rel="<?php if(isset($url) && $node->url == $url) print 'close'; ?>">
				<h4><?php print $node->title; ?></h4>
			</a>
		</li>
	  	<?php endforeach; ?>
	<?php endforeach; ?>
  </ul>
</div>
<div data-role="panel" id="right-panel" class="right-panel" data-display="push" data-position="right" data-theme="d">
  <ul data-role="listview" data-iscroll="true">
	<li data-role="list-divider" class="title">往期</li>
    <?php foreach ($issues as $id => $item): ?>
	    <li data-icon="false"><a href="<?php print $root['url'] . $item->id;?>.html">
			<img src="<?php print $root['url'] . $item->image; ?>"/>
			<h4><?php print $item->title; ?></h4>
			<p><?php print $item->name; ?></p>
		</a></li>
	<?php endforeach; ?>
  </ul>
</div>
