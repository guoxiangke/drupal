<div data-role="page" data-theme="d" data-dom-cache="true"
  class="mpage columns-<?php print count($nodes); ?>"
  id="section-<?php print $cid;?>"
  data-next="#left-panel"
  data-prev="#right-panel">
  <?php print $header; ?>
  <div data-role="content">
	<div class="content-primary">
		<?php $node = array_shift($nodes); ?>
		<ul>
		  <li><a data-url="#node-<?php print $node->nid; ?>">
		    	<?php if (isset($node->image['headline'])):?>
				<img src="<?php print $root['img'] . $node->image['headline']; ?>"/>
				<?php endif; ?>
				<h2><?php print $node->title; ?></h2>
				<p><?php print $node->summary; ?></p>
		  </a></li>
       	</ul>
    </div>
	<div class="content-secondary">
		<ul data-role="listview">
		<?php foreach ($nodes as $node): ?>
		  <li><a data-url="#node-<?php print $node->nid; ?>">
		    <?php if (isset($node->image['thumbnail'])):?>
    		<img src="<?php print $root['img'] . $node->image['thumbnail']; ?>"/>
    		<?php endif; ?>
			<h4><?php print $node->title; ?></h4>
			<p><?php print $node->abstract; ?></p>
	  	</a></li>
		<?php endforeach; ?>
		</ul>
	</div>
  </div><!-- content -->
</div><!-- page --> 	