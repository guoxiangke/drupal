<div data-role="page" data-theme="d" data-dom-cache="true" class="mpage home large"
	id="section-0"  
	data-next="#left-panel"
	data-prev="#right-panel"> 
  <?php print $header; ?>
  <div data-role="content">
	<div class="content-primary">
		<div class="flexslider">
  			<ul class="slides">
	  			<?php foreach ($headlines as $node): ?>
			    <li><a href="<?php print $root['url'] . $node->url;?>"
			    		data-nid="<?php print $node->nid; ?>" data-prefetch>
					<img src="<?php print $root['img'] . $node->image['headline']; ?>"/>
					<h3><?php print $node->title; ?></h3>
				</a></li>
    			<?php endforeach; ?>
  			</ul>
        </div>
	</div>
	<div class="content-secondary" >
		<ul class="nodelist" data-role="listview">
		<?php foreach ($columns as $column): ?>
			  <li class="column column-<?php print $column['id'];?>"><?php print $column['name']; ?></li>
  			  <?php foreach($column['nodes'] as $node): ?>
			    <li><a href="<?php print $root['url'] . $node->url;?>" 
			    		data-nid="<?php print $node->nid; ?>" data-prefetch>
					<img src="<?php print $root['img'] . $node->image['thumbnail']; ?>"/>
					<h4><?php print $node->title; ?></h4>
					<p><?php print $node->abstract; ?></p>
				</a></li>
			  <?php endforeach; ?>
		<?php endforeach; ?>
       	</ul>
	</div>
  </div>		
</div>
<?php 
foreach($sections as $section) {
	print $section;
}
?>