<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<div data-role="page" data-theme="d" data-dom-cache="true" class="mpage"
	id="node-<?php print $node->nid; ?>"
	data-next="node-<?php print $node->next; ?>"
	data-prev="node-<?php print $node->prev; ?>">
	<div data-role="header" data-id="footer" data-theme="a" data-position="fixed">
		<h1></h1>
		<div class="ui-btn-left" data-role="controlgroup" data-type="horizontal">
			<a href="#section-0" data-role="button" data-icon="bars" data-iconpos="notext" 
				data-shadow="false" data-iconshadow="false" class="ui-icon-nodisc"></a>
		</div>
	</div>
	<div data-role="content">
		<div class="node-content">
			<?php if (isset($node->image['headline'])): ?>
			<img src="<?php print $root['img'] . $node->image['headline']; ?>"/>
			<?php endif; ?>
			<h3 class="title"><?php print $node->title; ?></h3>
			<div class="date"><?php print $node->date; ?></div>
			<p class="summary"><?php print $node->summary; ?></p>
			<div class="body"><?php print $node->text; ?></div>
		</div>		
	</div>
</div>
</body>
</html>