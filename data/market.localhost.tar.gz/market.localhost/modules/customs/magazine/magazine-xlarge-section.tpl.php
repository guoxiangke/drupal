<div data-role="page" data-theme="d" data-dom-cache="true"
  class="mpage columns-<?php print count($nodes); ?>"
  id="section-<?php print $cid;?>"
  data-next="section-<?php print $next;?>"
  data-prev="section-<?php print $prev;?>">
  <?php print $header; ?>
  <div data-role="content">
	<div class="content-top">
		<?php print $name; ?>
	</div>
	<div class="content-primary">
		<?php $node = array_shift($nodes); ?>
		<ul>
		    <li><a data-url="#node-<?php print $node->nid;?>">
		    	<?php if (isset($node->image)):?>
				<img src="<?php print $root['img'] . $node->image; ?>"/>
				<?php endif; ?>
				<h2><?php print $node->title; ?></h2>
				<p><?php print $node->summary; ?></p>
			</a></li>
       	</ul>
    </div>
	<div class="content-secondary">
		<?php if (isset($class)): ?>
		  <div class= "ui-grid-<?php print $class;?>">
		<?php else: ?>
		  <div>
		<?php endif; ?>
		<?php foreach ($nodes as $node): ?>
			<?php if (isset($node->class)): ?>
			  <div class="ui-block-<?php print $node->class;?>">
			<?php else: ?>
			  <div>
			<?php endif; ?>
			  <a data-url="#node-<?php print $node->nid; ?>">
				<img src="<?php print $root['img'] . $node->thumbnail; ?>"/>
				<h4><?php print $node->title; ?></h4>
				<p><?php print $node->summary; ?></p>
			  </a>
			</div>
		<?php endforeach; ?>
		</div>
	</div>
  </div><!-- content -->	
</div><!-- page -->