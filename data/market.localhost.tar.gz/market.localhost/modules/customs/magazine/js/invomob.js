//------------------------------------------------------------------------------
// Listener

$(document).bind("pageload", onPageLoad);
$(document).on("pageinit", "[data-role='page'].mpage", onNodePageInit);
$(document).on("pageshow", "[data-role='page'].mpage", onNodePageShow);
$(document).on("pageshow", "#section-0.xlarge", onXlargeHomePageShow); 
$(document).on("pageshow", "#section-0.large", onLargeHomePageShow); 
$(document).on("orientationchange", onOrientationChange);

//------------------------------------------------------------------------------
// Event handler

function onPageLoad(event, data) {
	console.log(sprintf("page load: %s", data.url));
	var pages = data.xhr.responseText.split(MOBILE_PAGE_BREAK);
	// add other mobile pages, skip 1st and last.  
	for(var i = 1; i < pages.length - 1; i++) {
		$(pages[i]).appendTo($.mobile.pageContainer);
	}
}

function onNodePageInit() {
	var page = "#" + $(this).attr("id");
	var next = "#" + $(this).jqmData("next");
	var prev = "#" + $(this).jqmData("prev");
	console.log(sprintf("node init: %s", page));
	
	// Check if we did set the data-next attribute
	if (next) {
		// Navigate to next page on swipe right
		$(document).on("swipeleft", page, function() {
			console.log(sprintf("next page: %s", next));
			$.mobile.changePage(next, {transition: "slide"});
		});
	}
	// The same for the previous page (we set data-dom-cache="true" so there is no need to prefetch)
	if (prev) {
		$(document).on("swiperight", page, function() {
			console.log(sprintf("prev page: %s", prev));
			$.mobile.changePage(prev, {transition: "slide", reverse: true});
		});
	}
}

function onNodePageShow() {
	$("a[data-url]").click(function(event) {
		var url = $(this).jqmData('url');
		event.preventDefault();
		console.log("url: " + url);
		$.mobile.changePage(url);
	});	
}

function onXlargeHomePageShow() {
	$('.flexslider').flexslider();	
	$("a[data-url]").click(function(event) {
		var url = $(this).jqmData('url');
		event.preventDefault();
		if (LANDSCAPE == getOrientation()) {
			url = url + "-0";
		}
		$.mobile.changePage(url);
	});	
}

function onLargeHomePageShow() {
	width = $(window).width();
	height = width * 9 / 16;	
	$('.flexslider').width(width); 
	$('.flexslider').height(height); 
	$('.flexslider').flexslider();	
	$("a[data-url]").click(function(event) {
		var url = $(this).jqmData('url');
		event.preventDefault();
		console.log("url: " + url);
		$.mobile.changePage(url);
	});	
}

function onOrientationChange() {
	
}

function onAnchorClick(event) {
	var url = $(this).jqmData('url');
	if (url) {
		event.preventDefault();
		console.log("url: " + url);
		$.mobile.changePage(url);
	}
}

//------------------------------------------------------------------------------
// Util

function getOrientation() {
	mode = LANDSCAPE;
	if (window.orientation == 0) {
		mode = PORTRAIT;
	}
	return mode;
}

function getScreenSize() {
	size = XLARGE;
	var vars = getUrlVars();
	if (vars['size']) {
		size = vars['size'];
	};
	return size;
}

function getUrlVars(url) {
    var vars = [], hash;
    var hashes = url.slice(url.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
