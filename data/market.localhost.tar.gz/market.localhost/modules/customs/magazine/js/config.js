var TITLE = "汽车商业评论";
var SITENAME = "abr";

var MAX_HEADLINE = 2;
var PAGE_BREAK = /\<hr\s*\/\>/;
var MOBILE_PAGE_BREAK = "<!-- MOBILE PAGE BREAK -->";
var LANDSCAPE = "landscape";
var PORTRAIT = "portrait";

var NORMAL = 0;
var LARGE = 1;
var XLARGE = 2;

