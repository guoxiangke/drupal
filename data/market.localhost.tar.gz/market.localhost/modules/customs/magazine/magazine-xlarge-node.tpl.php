<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<div data-role="page" data-theme="d" data-dom-cache="true" class="mpage"
	id="node-<?php print $node->nid; ?>"
	data-next="node-<?php print $node->next; ?>"
	data-prev="node-<?php print $node->prev; ?>">
	<?php print $header; ?>
	<div data-role="content">
		<div class="node-content">
			<div class="content-top"> 
				<div class="column"><?php print $node->column; ?></div>
				<div class="date"><?php print $node->date; ?></div>
			</div>
			<div class="body"><?php print $node->body; ?></div>
		</div>		
	</div>
</div>
<!-- MOBILE PAGE BREAK -->
<?php foreach ($node->pages as $page): ?>
<div data-role="page" data-theme="d" data-dom-cache="true" class="mpage"
	id="node-<?php print $page->id; ?>"
	data-next="node-<?php print $page->next; ?>"
	data-prev="node-<?php print $page->prev; ?>">
	<?php print $header; ?>
	<div data-role="content">
		<div class="node-content">
			<div class="content-top"> 
				<div class="column"><?php print $page->column; ?></div>
				<div class="date"><?php print $page->date; ?></div>
			</div>
			<div class="body"><?php print $page->body; ?></div>
			<div class="pager"><?php print $page->pager; ?></div>
		</div>		
	</div>
</div>
<!-- MOBILE PAGE BREAK -->
<?php endforeach; ?>
</body>
</html>