<div data-role="header" data-id="footer" data-theme="a" data-position="fixed">
	<h1><?php print $title; ?></h1>
	<div class="ui-btn-left" data-role="controlgroup" data-type="horizontal">
		<a href="#left-panel" class="menu" data-role="button" data-icon="bars" data-iconpos="notext" 
			data-shadow="false" data-iconshadow="false" class="ui-icon-nodisc"></a>
	</div>
</div>
<div data-role="panel" id="left-panel" data-theme="a" class="left-panel">
  <ul data-role="listview" data-theme="a">
  	<?php foreach ($columns as $tid => $item): ?>
	    <li class="column column-<?php print $tid;?>">
	  	<a data-url="#section-<?php print $tid; ?>" data-rel="<?php if ($tid == $cid) print 'close'; ?>">
  		  <?php print $item['name']; ?>
  		</a>
	    </li>
	<?php endforeach; ?>
  </ul>
</div>
<div data-role="panel" id="right-panel" class="right-panel" data-display="push" data-position="right" data-theme="d">
</div>
