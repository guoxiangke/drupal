<div data-role="page" data-theme="d" data-dom-cache="true" class="home xlarge"
	id="section-0"  
	data-next="section-<?php print $next;?>"
	data-prev="section-<?php print $prev;?>"> 
  <?php print $header; ?>
  <div data-role="content">
	<div class="content-top">
		<?php print $name; ?>
	</div>
	<div class="content-primary">
		<div class="flexslider">
  			<ul class="slides">
	  			<?php foreach ($headlines as $node): ?>
			    <li><a href="<?php print $root['url'] . $node->url;?>"
			    		data-url="#node-<?php print $node->nid; ?>" data-prefetch>
					<img src="<?php print $root['img'] . $node->image; ?>"/>
					<h3><?php print $node->title; ?></h3>
				</a></li>
    			<?php endforeach; ?>
  			</ul>
        </div>
	</div>
	<div data-iscroll="true" class="content-secondary" >
	  <div style="min-height: 800px;">
  		<?php foreach ($columns as $cols): ?>
		<ul class="nodelist" data-role="listview">
  			<?php foreach ($cols as $column): ?>
			  <li class="column column-<?php print $column['id'];?>"><?php print $column['name']; ?></li>
  			  <?php $node = $column['nodes'][0]; ?>
			    <li><a href="<?php print $root['url'] . $node->url;?>" 
			    		data-url="#node-<?php print $node->nid; ?>" data-prefetch>
					<img src="<?php print $root['img'] . $node->thumbnail; ?>"/>
					<h4><?php print $node->title; ?></h4>
					<p><?php print $node->abstract; ?></p>
				</a></li>
			<?php endforeach; ?>
       	</ul>
		<?php endforeach; ?>
	  </div>
	</div>
  </div>		
</div>
<?php 
foreach($sections as $section) {
	print $section;	
} 
?>
