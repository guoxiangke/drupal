<li class="column column-news">新闻</li>
<li><a href="<?php print $root . $node->url;?>" 
		data-url="#node-<?php print $node->nid; ?>" data-prefetch>
	<img src="<?php print $root['url'] . $item->image['thumbnail']; ?>"/>
	<h4><?php print $node->title; ?></h4>
	<p><?php print $node->abstract; ?></p>
</a></li>
