(function ($) {

/**
 * JS related to the tabs in the Panels tabs.
 */
Drupal.behaviors.apptabs = {
  attach: function (context) {
    $("#tabs").tabs();
  }
};

})(jQuery);


