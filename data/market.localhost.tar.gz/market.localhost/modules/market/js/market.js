(function ($) {

/**
 * JS related to the tabs in the Panels tabs.
 */
Drupal.behaviors.market = {
  attach: function (context) {
    $("#tabs").tabs();
  }
};

})(jQuery);


