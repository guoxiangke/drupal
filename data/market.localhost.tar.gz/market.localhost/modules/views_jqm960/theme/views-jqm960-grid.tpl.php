<?php
/**
 * @file views-jqm-basic-list.tpl.php
 * Default jQM view template to display a grid.
 *
 * - $title : The title of this group of rows.  May be empty.
 */
?>

<?php if (!empty($title)) : ?>
  <h3><?php print $title; ?></h3>
<?php endif; ?>
<?php foreach ($rows as $row_number => $columns): ?>
    <div class="<?php print $class; ?>"<?php print $attributes; ?>>
        <?php foreach ($columns as $column_number => $item): ?>
          <div class="<?php print $column_classes[$row_number][$column_number]; ?>">
            <?php print $item; ?>
          </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>
</div>
