/*global define*/
define([
	'backbone',
	'config',
], function (Backbone, Conf) {
	'use strict';

	// The Model constructor
    var ArticleModel = Backbone.Model.extend({
    	
    	urlRoot: Conf.SERVER + Conf.ARTICLE_URL,
    	
    	initialize : function () {
        	this.fetch();
        	this.on('add', this.onAdd);
    	},
    
        onAdd: function(article) {
        	// set thumbnail if it doesn't exist!
        	if (!article.get('thumbnail')) {
        		article.set('thumbnail', '');
        	}
        	// TODO: why image is not set on server?
        	if (article.get('magazine_fields_image')) {
        		article.set('image', article.get('magazine_fields_image'));
        	}
        }
    });

    // Returns the Model class
    return ArticleModel;
});