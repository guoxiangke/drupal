/*global define*/
define([
    'jquery', 
    'backbone', 
    'views/headline',
    'views/thumbnail',
    'views/menu',
    'text!templates/main.html',
], function ($, Backbone, HeadlineView, ThumbnailView, MenuView, mainTemplate) {
	'use strict';
	
    // Extends Backbone.View
    var MainView = Backbone.View.extend( {
        
		// Compile our main template
		template: _.template(mainTemplate),
		
		// Delegated events for creating new items, and clearing completed ones.
		events: {
			'pageshow #home': onpageshow,
		},

		// At initialization we bind to the relevant events on the `Magazine`
		// collection, when items are added or changed. Kick things off by
		// loading any preexisting articles that might be saved in *localStorage*.
		initialize: function () {
            this.deferred = $.Deferred();
			this.$el.html(this.template());
		},
		
		// Re-rendering the App just means refreshing the statistics -- the rest
		// of the app doesn't change.
		render: function () {
			$(this.$el.html()).appendTo($.mobile.pageContainer);
			this.deferred.resolve();
			return this.deferred.promise();
		},
		
		onpageshow: function () {
			console.log('main pageshow');
		}
    });

    return MainView;	    // Returns the View class
});
