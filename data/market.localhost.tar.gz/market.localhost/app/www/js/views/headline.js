/*global define*/
define([ 
    'jquery', 
    'backbone',
    'config',
	'text!templates/headline.html',
	'phpjs'
], function ($, Backbone, Conf, headlineTemplate) {

	// Extends Backbone.View
    var HeadlineView = Backbone.View.extend({
    	
		template: _.template(headlineTemplate),

		// The DOM events specific to an item.
		events: {
		},

		// The HeadlineView listens for changes to its model, re-rendering. Since there's
		// a one-to-one correspondence between a **Article** and a **HeadlineView**, we 
		// set a direct reference on the model for convenience.
		initialize: function () {
            this.deferred = $.Deferred();
			this.listenTo(this.collection, 'reset', this.addAll);
			this.listenTo(this.collection, 'sync', this.addAll);
		},

		// Add a single article item to the list by creating a view for it, and
		// appending its element to the `<ul>`.
		addOne: function (article) {
			console.log('headline: ', article.get('image'));
			this.$el.append(this.template(article.toJSON()));
		},

		// Add all items in the **Magazine** collection at once.
		addAll: function () {
			this.$el.html('');
			var headlines = this.collection.filter(function(model){
				return model.get('headline') == '1' && model.get('image');
				}); 
			headlines = _.first(headlines, Conf.MAX_HEADLINES);
			_.each(headlines, this.addOne, this);
			this.deferred.resolve();
		},
		
		// Re-render the thumbnails.
		render: function () {
			return this.deferred.promise();
		},
	});

    return HeadlineView;	    // Returns the View class
});
