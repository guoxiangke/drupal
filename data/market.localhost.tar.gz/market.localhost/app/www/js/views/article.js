/*global define*/
define([ 
    'jquery', 
    'backbone',
	'text!templates/article.html',
    'phpjs',
], function ($, Backbone, pageTemplate) {
	
	var PAGE_BREAK = '<hr />';
	var PORTRAIT = 'portrait';
	var LANDSCAPE = 'landscape';
	
    // Extends Backbone.View
    var ArticleView = Backbone.View.extend({
    	
		template: _.template(pageTemplate),

		// The DOM events specific to an item.
		events: {
		},

		// The ArticleView listens for changes to its model, re-rendering. Since there's
		// a one-to-one correspondence between a **Article** and a **ArticleView**, we 
		// set a direct reference on the model for convenience.
		initialize: function () {
			this.listenTo(this.model, 'sync', this.addpages);
			this.listenTo(this.model, 'destroy', this.remove);
		},
		
		addpages: function() {
			// portrait page: single text page, no table, no images
			var node = this.model.toJSON();
			var body = node.body;	
			node.id = node.nid;
			node.body = strip_tags(body, '<br><p>');
			node.date = date('Y-m-d', node.date);
			node.page = 0;
			node.pages = 1;
			node.orientation = PORTRAIT;
			$(this.template(node)).appendTo($.mobile.pageContainer);
			
			// landscape page: multiple pages
			node.orientation = LANDSCAPE;
			var pages = body.split(PAGE_BREAK);
			node.pages = pages.length;
			for(var i = 0; i < pages.length; i++) {
				node.id = node.nid + "-" + i; 
				node.body = pages[i];
				node.page = i;
				node.pager = (i + 1)+ '/' + pages.length;
				$(this.template(node)).appendTo($.mobile.pageContainer);
			}
			this.trigger('ready', 'node-' + this.model.id + '-0');
		},

		// Render the article.
		render: function () {
			return this;
		},
		
		remove: function () {
		},
	});

    return ArticleView;	    // Returns the View class
});
