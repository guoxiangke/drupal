/*global define*/
define([ 
    'jquery', 
    'backbone',
	'text!templates/thumbnail.html',
	'phpjs'
], function ($, Backbone, thumbnailTemplate) {

	var MAX_SUMMARY = 35;
    
	// Extends Backbone.View
    var ThumbnailView = Backbone.View.extend({
    	
		template: _.template(thumbnailTemplate),

		// The DOM events specific to an item.
		events: {
		},

		// The ThumbnailView listens for changes to its model, re-rendering. Since there's
		// a one-to-one correspondence between a **Article** and a **ThumbnailView**, we 
		// set a direct reference on the model for convenience.
		initialize: function () {
			this.thumbnails = [];
            this.deferred = $.Deferred();
			this.listenTo(this.collection, 'add', this.addOne);
			this.listenTo(this.collection, 'reset', this.addAll);
			this.listenTo(this.collection, 'sync', function() {
				this.addAll();
				this.deferred.resolve();
			});
		},

		// Add a single article item to the list by creating a view for it, and
		// appending its element to the `<ul>`.
		addOne: function (article) {
			var node = article.toJSON();
			node.summary = strip_tags(node.summary).slice(0, MAX_SUMMARY);
			this.thumbnails[node.cid] = node;
		},

		renderOne: function (node) {
			this.$el.append(this.template(node));
		},
		
		// Add all items in the **Magazine** collection at once.
		addAll: function () {
			this.$el.html('');
			//var size = (this.collection.length + 1) / 2;
			//groups.b = _.rest(this.collection, size);
			// MUST pass this as context!
			_.each(this.thumbnails, this.renderOne, this);
		},
		
		// Re-render the thumbnails.
		render: function () {
			return this.deferred.promise();
		},
	});

    return ThumbnailView;	    // Returns the View class
});
