/*global define*/
define([ 
    'jquery', 
    'backbone',
	'text!templates/menu.html',
], function ($, Backbone, menuTemplate) {
	
    // Extends Backbone.View
    var MenuView = Backbone.View.extend({
    	
		template: _.template(menuTemplate),

		// The DOM events specific to an item.
		events: {
		},

		// The MenuView listens for changes to its model, re-rendering. Since there's
		// a one-to-one correspondence between a **Article** and a **MenuView**, we 
		// set a direct reference on the model for convenience.
		initialize: function () {
			this.articles = [];
            this.deferred = $.Deferred();
			this.listenTo(this.collection, 'add', this.addOne);
			this.listenTo(this.collection, 'reset', this.addAll);
			this.listenTo(this.collection, 'sync', function() {
				this.addAll();
				this.deferred.resolve();
			});
		},
		
		// Add a single article item to the list by creating a view for it, and
		// appending its element to the `<ul>`.
		addOne: function (article) {
			var node = article.toJSON();
			if (!_.isArray(!this.articles[node.cid])) {
				this.articles[node.cid] = [];
				this.articles[node.cid].nodes = [];
			}
			this.articles[node.cid].cid = node.cid;
			this.articles[node.cid].column = node.column;
			this.articles[node.cid].nodes.push(node);
		},

		renderCol: function (col) {
			this.$el.append(this.template(col));
		},
		
		// Add all items in the **Magazine** collection at once.
		addAll: function () {
			this.$el.html('');
			_.each(this.articles, this.renderCol, this);
		},
		
		// Re-render the thumbnails.
		render: function () {
			return this.deferred.promise();
		},
	});

    return MenuView;	    // Returns the View class
});
