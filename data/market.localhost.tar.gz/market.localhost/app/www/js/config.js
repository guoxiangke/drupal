/*global define*/
define({
	SERVER: 'http://abr.exue365.cn',
	ARTICLE_URL: '/api/article',
	MAGAZINE_URL: '/svc/magazine/content',
	
	MAX_HEADLINES: 3,
});