/*global define*/
define([
    'jquery',
    'backbone',
    'config',
    'models/article'
], function ($, Backbone, Conf, Article) {

	// Extends Backbone.Router
    var MagazineCollection = Backbone.Collection.extend({
        
    	url: Conf.SERVER + Conf.MAGAZINE_URL,
    
        // Sets the Collection model property to be a article Model
        model: Article,
        
    	// The Collection constructor
    	initialize: function(models, options) {
        },
    });

    return MagazineCollection;	// Returns the Model class
});
