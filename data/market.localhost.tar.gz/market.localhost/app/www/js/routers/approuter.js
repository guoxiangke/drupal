/*global define*/
define([
    'jquery',
    'backbone', 
    'collections/magazine',
    'models/article',
    'views/article',
    'views/main'
], function ($, Backbone, Magazine, Article, ArticleView, MainView) {

	// Extends Backbone.Router
    var AppRouter = Backbone.Router.extend({
    
        initialize:function () {
        	this.mainView = new MainView();
        },
    	
        // Backbone.js Routes
        routes: {
            // When there is no hash bang on the url, the home method is called
            '': 'home',
            'home': 'home',
            'article/:id': 'showArticle',
            'section/:id': 'showSection',
            'menu/:id': 'showMenu'
        },

        // Home method
        home: function() {
        	$.when(this.mainView.render()).done( _.bind(this.changePage, this, 'home'));
        },
        
        showArticle: function(id, slide, reverse) {
        	if ($('#node-' + id).length > 0) {
        		this.changePage('#node-' + id, slide, reverse);
        	}
        	else {
	        	var data = new Article({id:id});
	            var view = new ArticleView({model:data});
	            this.createPage(view, slide, reverse);
        	}
        },
         
        createPage: function (view, transition, reverse) {
        	if (_.isObject(view)) {
        		var self = this;
	        	view.on("ready", function(pid) {
	        		self.changePage(pid, transition, reverse);
	        	});
        	}
        	else {
        		this.changePage(view, transition, reverse);
        	}
        },

        changePage: function (pid, transition, reverse) {
    		console.log("change page: " + pid);
            if (!transition) {
            	transition = $.mobile.defaultPageTransition;
            } 
            $.mobile.changePage("#" + pid, {
            	changeHash:true, 
            	transition: transition,
            	reverse: reverse
            });
    	},
        
    	orientationChange: function (orientation) {
    		
    	},
    	
        nextl: function (id) {
        },

        prevl: function (id) {
        },
        
        nextp: function (id) {
        	//showArticle();
        },
        
        prevp: function (nid) {
        	//showArticle();
        }
    });

    // Returns the Router class
    return AppRouter;
});