/*global require*/
'use strict';

// Sets the require.js configuration for your application.
require.config({
    // 3rd party script alias names (Easier to type 'jquery' than 'libs/jquery-1.8.2.min')
	paths: {
        // Core Libraries
		jquery: 'libs/jquery',
        jquerymobile: 'libs/jquerymobile',
        underscore: 'libs/underscore',
        backbone: 'libs/backbone',
    	backboneLocalstorage: 'libs/backbone.localStorage',
    	text: 'libs/text',
    	sprintf: 'libs/sprintf',
    	phpjs: 'libs/phpjs',
    	flexslider: 'libs/jquery.flexslider',
    	iscroll: 'libs/iscroll',
    	jqmiscroll: 'libs/jquery.mobile.iscrollview',
	},
	// The shim config allows us to configure dependencies for
	// scripts that do not call define() to register a module
	shim: {
        backbone: {
        	deps: [ 'underscore', 'jquery' ],
        	exports: 'Backbone',  // attaches 'Backbone' to the window object
        },
		backboneLocalstorage: {
			deps: [ 'backbone' ],
			exports: 'Store',
		},
        jquerymobile: {
        	deps: [ 'jquery' ],
        },
		jqmiscroll: {
			deps: [ 'jquerymobile', 'flexslider', 'iscroll']
		}
	} // end Shim Configuration
});

require([
    'jquery', 
    'backbone', 
    'routers/approuter'
], function ($, Backbone, AppRouter) {
	/*jshint nonew:false*/

	$(document).on('mobileinit',
		// Set up the 'mobileinit' handler before requiring jQuery Mobile's module
		function() {
			// Prevents all anchor click handling including the addition of active 
			// button state and alternate link bluring.
			$.mobile.linkBindingEnabled = false;
			// Disabling this will prevent jQuery Mobile from handling hash changes
			$.mobile.hashListeningEnabled = false;
		}
	);

	// Important! otherwise mobileinit won't be fired.
	require([
	    'flexslider',
	    'jquerymobile',
	    'jqmiscroll'
	], function () {
		// Instantiates a new Backbone.js Mobile Router
		var router = new AppRouter();
	    
		// TODO: how to do this in in view?
		$(document).on('swipeleft', '.portrait', function() {
	    	router.nextp($(this).jqmData('nid'));
		});
		$(document).on('swiperight', '.portrait', function() {
	    	router.prevp($(this).jqmData('nid'));
		});
		$(document).on('swipeleft', '.landscape', function() {
	    	router.nextl($(this).jqmData('nid'));
		});
		$(document).on('swiperight', '.landscape', function() {
	    	router.prevl($(this).jqmData('nid'));
		});
		
	    // Tells Backbone to start watching for hashchange events
	    Backbone.history.start();
	});
});