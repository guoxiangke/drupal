{
    "appDir": "../www",
    "baseUrl": "js/lib",
    "paths": {
        "app": "../app"
    },
    "dir": "../www-built",
    "modules": [
        {
            "name": "app"
        }
    ]
}
